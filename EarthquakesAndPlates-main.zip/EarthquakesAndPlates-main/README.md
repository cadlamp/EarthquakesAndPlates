# Earthquakes and Plate Tectonics

Team members:
Eli Hess,Adam Fuegmann,Cadence Lamphiear

The files in the [public](/public) directory are deployed to: https://cse442.pages.cs.washington.edu/24wi/final-project/EarthquakesAndPlates/
