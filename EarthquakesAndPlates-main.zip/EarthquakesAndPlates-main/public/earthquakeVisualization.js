const { geoEqualEarth, geoPath, scaleLog, extent, descending, select, zoom, interpolate, zoomIdentity} = d3

const projection = geoEqualEarth()
    .scale(200)
    .center([-20, 15])
    .rotate([-162, 0]); // Center the projection on the Pacific Ocean
const path = geoPath(projection);
const linesCoordinates = [
  { A: [-170, -24.5], B: [174.5, -21], group: "Tonga" },
  { A: [163.5, -17.25], B: [172, -15.25], group: "Solomon" },
  { A: [-80, -16.5], B: [-62, -13], group: "Andes" },
  { A: [150, 35], B: [126, 46], group: "Japan" },
  { A: [-96, 11], B: [-90, 18.5], group: "Central America" }
];

const ABCoordinates = [
  { A: [-170, -23.5], B: [174.5, -20.25], group: "Tonga" },
  { A: [163.5, -16], B: [172, -14.5], group: "Solomon" },
  { A: [-80, -15.5], B: [-62, -12.25], group: "Andes" },
  { A: [150, 36.5], B: [126, 46.5], group: "Japan" },
  { A: [-98, 11], B: [-92, 18.5], group: "Central America" }
];

let data;
let tooltip;
let filteredData;
let countryData;
let mapBody, bordersGroup, linesGroup, ABGroup;
let plateData;
let zoomLevel = 1;
let selectedRegions = new Set();
let thresholdZoomLevel = 2;
let tooltipVisible = 0;
let magnitudeFilter = [1, 10]
let depthFilter = [0, 700]
let platesVisible = 1;
let colorScale;
let rScale;


export const earthquakeVisualization = (selection) => {  

  //let earthquakeSVG = selection;

  const generateMap = (earthquakeSVG) => {
    // Remove underlying maps?
    // earthquakeSVG.html('')

    createColorScale();
    
    createRScale();

    // Setting up tooltip
    tooltip = select("body")
        .selectAll("div#tooltip")
        .data([null])
        .join("div")
        .attr("id", "tooltip")
        .style("position", "absolute")
        .style("opacity", `${tooltipVisible ? 1 : 0}`)
        .style("display", "absolute")
        .style("background", "white")
        .style("border-radius", "5px")
        .style("border-color", "black")
        .style("border-style", "solid")
        .style("padding", "5px")
        .style("z-index", "-1")

    // tooltipInfo object that you are going to include in the tooltip
    // Increase range if you are adding more info to the tooltip
    // This will add more placeholder items to the data that will be replaced
    // by the data from within the tooltipsInfo array when we trigger and event
    // and repopulate the divs of the tooltip with new information
    tooltip
        .selectAll("div")
        .data(d3.range(6))
        .join("div")

    // Setting up the map
    mapBody = earthquakeSVG
      .append('g')
      .attr("id", "map")

    // Group for country and plate borders
    bordersGroup = mapBody
      .append("g")
      .attr("id", "borders-group");
    
    // Append lines AtoB to the map body
    linesGroup = bordersGroup
    .append("g")
    .attr("id", "lines-group");

    // Append A - B to the map body
    ABGroup = bordersGroup
    .append("g")
    .attr("id", "lines-group");

    // Setting up paths on map
    bordersGroup
        .selectAll("path.country-border")
        .data(countryData.features)
        .join("path")
        .attr("class", "country-border")
        .attr("d" , (d) => path(d))
        .attr("stroke", "black")
        .attr("stroke-width", 0.6)
        .attr("fill", "hsl(82, 30%, 30%)");

    // Append a blue rectangle behind the country and plate borders
    bordersGroup      
      .append("rect")
      .attr("rx", "22%")
      .style("width", "88%")
      .style("height", "89%")
      .attr("fill", "hsl(219, 45%, 60%)")
      .attr("x", -15)
      .attr("y", 45)
      .attr("stroke", "#03045e")
      .attr("stroke-width", '0.2rem')
      .style("border-radius", "10px")
      .lower();

      // Enable zoom behavior
      earthquakeSVG.call(zoom()
        .scaleExtent([1, 8])
        .translateExtent([[-165, -25], [1245, 645]])
        .on('zoom', handleZoom));
  
    bordersGroup
      .selectAll("path.plate-border")
      // .data(subductionBorders)
      .data(plateData.features)
      .join("path")
      .attr("class", "plate-border")
      .attr("d" , (d) => path(d))
      .attr("stroke", "lightgrey")
      .attr("fill", "none")
      .attr('opacity', .75);      

    
  }

  //*************************************//
  //          HELPER FUNCTIONS           //
  //*************************************//

  // The scale for the colors
  function createColorScale() {
    // Sets up a color scale for the points based on depth
    colorScale = (depth) => {
    if (depth <= 70) {
      // Scale depths from 0 to 70 km using blue to yellow color interpolation
      // These are considered shallow earthquakes
      return interpolate("blue", "yellow")(depth / 70);
    } else  if (depth <= 250){
      // Scale depths from 70 to 300 km using blue to red color interpolation
      // These are considered intermediate earthquakes
      return interpolate("yellow", "red")(depth / 250);
    } else {
      // Depths beyond 250 km are mapped to the color red
      // These are considered deep earthquakes
      return "red";
    }};
  }

  // The radius scale
  function createRScale() {
    // Sets up radius scaling for points based on magnitude
    rScale = scaleLog(extent(data, (d) => d.magnitude), [1,10]);
  }

  function filterData(){
    // Filtering by depth and magnitude
    filteredData = data.filter((d) =>{
      if (depthFilter[0] <= d.depth && d.depth <= depthFilter[1] &&
        magnitudeFilter[0] <= d.magnitude && d.magnitude <= magnitudeFilter[1] &&
        ((d.magnitude > 7 || d.depth <= 11) || (d.magnitude > 6.5 && zoomLevel > thresholdZoomLevel * 0.8) || 
        (d.magnitude > 6 && zoomLevel > thresholdZoomLevel * 1.25))) {
        return d;
      }
    })
    console.log(filteredData);
  }

  // Function to filter lines based on selected regions
  function filterLines() {
    return linesCoordinates.filter(line => selectedRegions.has(line.group));
  }

  // Function to filter lines based on selected regions
  function filterAB() {
    return ABCoordinates.filter(point => selectedRegions.has(point.group));
  }

  function sortData() {
    // Sorts data based on smallest point so we draw biggest circles
    // first and smaller circles are drawn on top so we can select them
    filteredData = filteredData.sort((x,y) => {
      return descending(x.magnitude, y.magnitude);
    });
  }

  function handleZoom(event) {
    zoomLevel = event.transform.k;
    bordersGroup
      .attr('transform', event.transform);
    filterData();
    generateMap.update();
  }

  //*************************************//
  //          ANONYMOUS FUNCTIONS        //
  //*************************************//

  generateMap.update = function() {
    
    filterData();

    const filteredLines = filterLines();
    const filteredAB = filterAB();

    // Update selection with filtered lines
    const lineSelection = linesGroup.selectAll("line").data(filteredLines);

    // Remove lines that are not part of the filtered selection
    lineSelection.exit().remove();

    // Enter new lines from the filtered selection
    const newLines = lineSelection.enter().append("line");

    // Merge new and existing lines
    const mergedLines = newLines.merge(lineSelection);

    // Update attributes of merged lines
    mergedLines
        .attr("x1", d => projection(d.A)[0])
        .attr("y1", d => projection(d.A)[1])
        .attr("x2", d => projection(d.B)[0])
        .attr("y2", d => projection(d.B)[1])
        .attr("stroke", "white")
        .attr("stroke-width", 2);

     // Update selection with filtered points for label 'B'
    const pointBSelection = ABGroup.selectAll(".label-B").data(filteredAB);

    // Remove existing text elements that are not part of the filtered selection
    pointBSelection.exit().remove();

    // Update existing elements with class 'label-B'
    pointBSelection
        .attr("x", d => projection(d.B)[0])
        .attr("y", d => projection(d.B)[1])
        .attr("text-anchor", "middle")
        .attr("fill", "white")
        .text("B");

    // Enter new text elements for filtered selection of label 'B'
    const newBTexts = pointBSelection.enter().append("text")
        .attr("class", "label-B")
        .attr("x", d => projection(d.B)[0])
        .attr("y", d => projection(d.B)[1])
        .attr("text-anchor", "middle")
        .attr("fill", "white")
        .text("B");

    // Update selection with filtered points for label 'A'
    const pointASelection = ABGroup.selectAll(".label-A").data(filteredAB);

    // Remove existing text elements that are not part of the filtered selection
    pointASelection.exit().remove();

    // Update existing elements with class 'label-A'
    pointASelection
        .attr("x", d => projection(d.A)[0])
        .attr("y", d => projection(d.A)[1])
        .attr("text-anchor", "middle")
        .attr("fill", "white")
        .text("A");

    // Enter new text elements for filtered selection of label 'A'
    const newATexts = pointASelection.enter().append("text")
        .attr("class", "label-A")
        .attr("x", d => projection(d.A)[0])
        .attr("y", d => projection(d.A)[1])
        .attr("text-anchor", "middle")
        .attr("fill", "white")
        .text("A");
    
    // Setting up data
    const mapMarks = filteredData.map(d => ({
      coords: projection([d.longitude, d.latitude]).join(","),
      color: colorScale(d.depth),
      region: d.state,
      r: rScale(d.magnitude),
      outline: "1",
      // Put these in the tooltip later using event function
      tooltipInfo: [
          d.title,
          d.latitude,
          d.longitude,
          d.magnitude,
          d.depth,
          d.tsunami
      ]
    }));

    bordersGroup
      .selectAll("g#circle-container")
      .data([null]) // since there is only one, it matches it to the existing one if there is or creates one
      .join("g")
      .attr("id", "circle-container")
      .selectAll("circle")
      .data(mapMarks)
      .join("circle")
      .attr("r", d => (selectedRegions.has(d.region)) ? 2 * d.r / (Math.pow(zoomLevel, 0.4)) : d.r / (Math.pow(zoomLevel, 0.4)))
      .attr("transform", d => `translate(${d.coords})`)
      .attr("fill", d => d.color)
      .attr("stroke", "black")
      .attr("stroke-width", d => (selectedRegions.has(d.region)) ? 1.75 * d.outline / (Math.pow(zoomLevel, 0.4)) : d.outline / (Math.pow(zoomLevel, 0.4)))
      .attr("opacity", 0.7)
      // .attr("filter", "url(#glow)")
      .on('mouseover', function (event, eventData) {
        select(this)
        // MAYBE REMOVE THIS
          .transition()
          .duration(50)
          .attr("r", d => (selectedRegions.has(d.region)) ? 4 * d.r / (Math.pow(zoomLevel, 0.4)) : 2 * d.r / (Math.pow(zoomLevel, 0.4)));
        // Changing settings of tooltip
        tooltipVisible = true;
        tooltip
            .style("opacity", 1)
            .style("left", `${event.pageX + 20}px`)
            .style("top", `${event.pageY - 20}px`)
            .style("z-index", "999")
        tooltip
            .selectAll("div")
            // Gets the tooltip info array from event data
            .data(eventData.tooltipInfo)
            // We will create a div to hold text for all pieces of data
            .join("div")
            // checking if our data is the title and assign that div a css class that will make it bold
            .classed("bold-text", (d, i) => i === 0)
            .text((d, i)=>{
                switch (i) {
                    case 0:
                        return `${eventData.tooltipInfo[i]}`;
                    case 1:
                        return `Date/Time: ${eventData.tooltipInfo[i]}`;
                    case 2:
                        return `Location: ${eventData.tooltipInfo[i]}`;
                    case 3:
                        return `Magnitude: ${eventData.tooltipInfo[i]}`;
                    case 4:
                        return `Depth: ${eventData.tooltipInfo[i]}km`;
                    case 5:
                        return `Tsunami Threat: ${eventData.tooltipInfo[i] === 1 ? "Yes" : "No"}`;
                    default:
                        return ""
                }
            });
    })
    .on('mouseout', function (event, eventData) {
        select(this).transition()
            .duration('50')
            .attr("r", d => (selectedRegions.has(d.region)) ? 2 * d.r / (Math.pow(zoomLevel, 0.4)) : d.r / (Math.pow(zoomLevel, 0.4)));
        // Changing settings of tooltip
        tooltipVisible = false;
        tooltip
            .data([null])
            .join("div")
            .attr("id", "tooltip")
            .style("opacity", 0)
            .style("z-index", "-1");
    });
    linesGroup.raise();
    ABGroup.raise();
    return generateMap;
  }

  // Raise or lower the plate borders to make them visible on toggle
  generateMap.updateBorder = function () {
    if (platesVisible) {
      bordersGroup
        .selectAll("path.plate-border")
        .raise()
      mapBody.selectAll("chart").raise()
    } else {
      bordersGroup
        .selectAll("path.plate-border")
        .lower()
      mapBody.selectAll("chart").lower()
      
    }
  }

  generateMap.data = function (_) {
    if (arguments.length) {
      data = _;
      var pLat, pLong;

      // Iterate through each object in the data array
      data.forEach(d => {
          pLat = d.latitude;
          pLong = d.longitude;

          // Check the longitude and latitude coordinates and update the state field accordingly
          if (-40 < pLat && pLat < -14 && (178 < pLong || pLong < -172)) {
            d.state = "Tonga";
          } else if (-24 < pLat && pLat < -3 && 145 < pLong && pLong < 174) {
            d.state = "Solomon";            
          } else if (-39 < pLat && pLat < 5 && -80 < pLong && pLong < -60) {
            d.state = "Andes";            
          } else if ((10 < pLat && pLat < 35 && 137 < pLong && pLong < 147)
                    || (35.5 < pLat && pLat < 63 && 129 < pLong && pLong < 171.1)) {
            d.state = "Japan";
          } else if ((7 < pLat && pLat < 14 && -90 < pLong && pLong < -82)
                    || (13 < pLat && pLat < 20 && -110 < pLong && pLong < -90)) {
            d.state = "Central America";            
          }
      });
      console.log(data);
      return generateMap;
  } else {
      return data;
  }
  }


  generateMap.regionHighlight = function (_) {
    return arguments.length ? ((selectedRegions = _), generateMap) : selectedRegions;
  }

  generateMap.countryData = function (_) {
    return arguments.length ? ((countryData = topojson.feature(_, _.objects.countries)), generateMap) : countryData;
  }

  generateMap.plateData = function (_) {
    return arguments.length ? ((plateData = topojson.feature(_, _.objects.PB2002_boundaries)), generateMap) : plateData;
  }
  
  generateMap.magnitudeFilter = function (_) {
    return arguments.length ? ((magnitudeFilter = _), generateMap) : magnitudeFilter;
  }
  
  generateMap.depthFilter = function (_) {
    return arguments.length ? ((depthFilter = _), generateMap) : depthFilter;
  }
  
  generateMap.platesVisible = function (_) {
    return arguments.length ? ((platesVisible = _), generateMap) : platesVisible;
  }


  
  return generateMap;
}
