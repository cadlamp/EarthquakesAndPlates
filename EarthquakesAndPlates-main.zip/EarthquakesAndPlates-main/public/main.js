import { earthquakeVisualization } from "./earthquakeVisualization.js";
import { graphVisualization }      from "./crossSectionGraph.js";
import { legend }                  from "./legend.js";
import { slider }                  from "./slider.js"
import { depthSlider }             from "./depthSlider.js"
import { toggle }                  from "./toggle.js";
import { generateXAxis }           from "./xAxis.js";

const {select, csv, json} = d3;

const datasetLink =        "./data/newData.csv"
const platesTopoJsonLink = "./data/mygeodata/PB2002_boundaries.topojson"
const topoJsonLink =       "https://www.unpkg.com/visionscarto-world-atlas@0.1.0/world/110m.json"

// Auto scales map
const svg = select("body")
    .select("div#vis-container")
    .append("svg")
    .attr("preserveAspectRatio", "xMinYMin meet")
    .attr("viewBox", `-50 17 1260 600`)
    // Class to make it responsive.
    .classed("svg-content-responsive", true)
    .style("max-width", "100%")

// A function that takes in a row of data and does conversions
const parseRows = (d) => {
    d.tsunami = +d.tsunami;
    d.significance = +d.significance;
    d.magnitude = +d.magnitude;
    d.latitude = +d.latitude;
    d.longitude = +d.longitude;
    d.depth = +d.depth;

    // Extract year from the date_time field
    // const dateParts = d.date_time.split(' ')[0].split('-');
    const dateParts = d.date.split(' ')[0].split('-');
    if (dateParts.length === 3) {
        d.year = parseInt(dateParts[0]);
    } else {
        d.year = null; // Handle invalid date formats
    }

    return d;
}

const main = async () => {

    // Load the data
    const data = await csv(datasetLink, parseRows);

    // Initialize an instance of the map
    const eMap = earthquakeVisualization()
      .data(data)
      .countryData(await json(topoJsonLink))
      .plateData(await json(platesTopoJsonLink, Headers));

    const graphSelector = (region) => {
      console.log(region);
      eMap.regionHighlight(region);
      eMap.update();
    }

    // Initialize an instance of the graphs
    const graph = graphVisualization()
      .data(data)
      .plateData(await json(platesTopoJsonLink, Headers))
      .graphFilter(graphSelector);

    // Initialize an instance of the legend
    const mapLegend = legend()
      .data(data);

    // A setter function for the mag slider
    const magnitudeSetter = (magnitudes) => {
        console.log(magnitudes);
        eMap.magnitudeFilter(magnitudes);
        eMap.update();
    }

    // Initialize an instance of the magnitude slider
    const magnitudeSlider = slider()
        .selectionName("Filter by Magnitude")
        .selectionId("filter-by-magnitude")
        .data(data)
        .dataSetter(magnitudeSetter);

    
    // A setter function for the depth slider
    const depthSetter = (depth) => {
        console.log(depth);
        eMap.depthFilter(depth);
        // eMap.graph();
        eMap.update();
    }

    // Initialize an instance of the depth slider
    const myDepthSlider = depthSlider()
        .selectionName("Filter by Depth")
        .selectionId("filter-by-depth")
        .data(data)
        .dataSetter(depthSetter);
    
    // A setter function for the toggle
    const plateToggler = (val) => {
      eMap.platesVisible(val);
        eMap.updateBorder();
    }

    // Initialize an instance of the plate toggle
    const plateToggle = toggle()
      .toggleId("boundary-toggle")
      .dataSetter(plateToggler)
      .toggleName("Plate Boundaries");

    // Call the map and legend instance from the svg
    svg.call(eMap);
    svg.call(mapLegend);
    
    // Append the sliders to their slider containers
    const depthSliderContainer = select("div#depth-slider");
    const magSliderContainer = select("div#mag-slider");
    depthSliderContainer.call(myDepthSlider);
    magSliderContainer.call(magnitudeSlider);

    // Append the toggle to the toggle container
    const controlsContainer = select("div#boundary-toggle");
    controlsContainer.call(plateToggle);   


    const legendContainer = select("div#legend");
    legendContainer.call(mapLegend);

    generateXAxis();
    const graphContainer = select("div#graph")
    graphContainer.call(graph);
}


main().then();
