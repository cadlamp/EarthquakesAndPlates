export const menu = (selection) => {

    let selectionName;
    let data;
    let selectionId;
    let dataFilterer;
    let dataSetter;
    let nameForEmptyData = "";

    const my = (selection) => {

        // Setting up a set of unique options from the given data and excluding empty string
        // If a nameForEmptyData is specified, we will add this to the selection if there is
        // data with no name
        const options = new Set();
        options.add("");
        d3.map(dataFilterer(data), (item) => {
            if (nameForEmptyData !== "" && !options.has(nameForEmptyData) && item === "") {
                options.add(nameForEmptyData);
            } else if (!options.has(item) && item !== "") {
                options.add(item);
            }
        });

        // Convert to array, sort, and use the data
        const optionsArr = Array.from(options);
        optionsArr.sort();

        // Puts the nameForEmptyData category at the bottom
        if (nameForEmptyData !== "") {
            optionsArr.sort((a,b) => {if (b === nameForEmptyData) {return -1}})
        }

        // Finally build up the selection
        const selectionContainer = selection
            .selectAll(`div#${selectionId}`)
            .data([null]) // since there is only one, it matches it to the existing one if there is or creates one
            .join("div")
            .attr("id", selectionId)
            .style("display", "flex")
            .style("justify-content", "left")
            .style("flex-shrink", "1")


        const selectionLabel = selectionContainer
            .append("label")
            .text(selectionName)
            .style("margin", "auto 0 auto 0")

        const selectionItself = selectionContainer
            .append("select")
            .style("width", "90%")
            .style("margin", "auto 4% auto 5px")
            .style("text-overflow", "ellipsis")
            .on('change', function (event) {
                console.log(event.target.value);
                dataSetter(event.target.value);
            })

        const selectionOptions = selectionItself
            .selectAll("option");

        selectionOptions
            .append("option")
        selectionOptions
            .data(optionsArr)
            .join("option")
            .attr("value", d => d)
            .text(d => d)

    }

    my.selectionName = function (_) {
        return arguments.length ? ((selectionName = _), my) : selectionName;
    }

    my.data = function (_) {
        return arguments.length ? ((data = _), my) : data;
    }

    my.selectionId = function (_) {
        return arguments.length ? ((selectionId = _), my) : selectionId;
    }

    my.dataFilterer = function (_) {
        return arguments.length ? ((dataFilterer = _), my) : dataFilterer;
    }

    my.dataSetter = function (_) {
        return arguments.length ? ((dataSetter = _), my) : dataSetter;
    }

    my.nameForEmptyData = function (_) {
        return arguments.length ? ((nameForEmptyData = _), my) : nameForEmptyData;
    }
    return my;
}