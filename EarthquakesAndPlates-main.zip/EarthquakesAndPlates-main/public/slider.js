export const slider = () => {
    let selectionName;
    let data;
    let selectionId;
    let dataSetter;
    

    const my = (selection) => {
        const sliderValues = selection
            .append("div")
            .attr("id", "slider-values");

        // Your slider initialization logic here
        const sliderContainer = selection
            .append("div")
            .style("width", "250px")
            .style("margin-left", "10px");

        const magnitudeValues = data.map(d => d.magnitude);
    
        const slider = noUiSlider.create(sliderContainer.node(), {
            start: [6.0, 10.0], // Initial range values
            // orientation: 'vertical',
            step: 0.1,
            range: {
                min: Math.min(...magnitudeValues),
                max: Math.max(...magnitudeValues)
            }
        });
    
        // Attach an event listener to update the visualization when the slider values change
        slider.on('update', (values) => {
            // Update the corresponding value element based on the handle
            sliderValues.text('Magnitude: ' + values.join(' - '));
    
            // Pass the slider values to the dataFilterer function
            const selectedMagnitudeStart = +values[0];
            const selectedMagnitudeEnd = +values[1];
    
            // Pass the filtered data to the dataSetter function
            dataSetter([selectedMagnitudeStart, selectedMagnitudeEnd]);
        });
    }

    my.selectionName = function (_) {
        return arguments.length ? ((selectionName = _), my) : selectionName;
    }

    my.data = function (_) {
        return arguments.length ? ((data = _), my) : data;
    }

    my.selectionId = function (_) {
        return arguments.length ? ((selectionId = _), my) : selectionId;
    }

    my.dataSetter = function (_) {
        return arguments.length ? ((dataSetter = _), my) : dataSetter;
    }

    return my;
}
