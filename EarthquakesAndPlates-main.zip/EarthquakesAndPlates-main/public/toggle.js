export const toggle = (selection) => {

    let toggleId;
    let dataSetter;
    let toggled = 1;
    let toggleName = "";

    const my = (selection) => {

        // selection
        //     .append("label")
        //     .text(toggleName)
        //     .style("padding", "0 10px 0 10px");

        const toggleContainer = selection.selectAll(`div#${toggleId}`)
            .data([null]) // since there is only one, it matches it to the existing one if there is or creates one
            .join("div")
            .attr("id", toggleId)
            .style("display", "flex")
            .style("align-items", "center")
            .style("justify-content", "right")
            .style("position", "relative");

        toggleContainer
            .append("label")
            .text(toggleName)
            .style("padding", "0 5px 0 5px")
            .style("margin", "auto 0");

        const toggle = toggleContainer.selectAll("label.switch")
            .data([null]) // since there is only one, it matches it to the existing one if there is or creates one
            .join("label")
            .classed("switch", true)
            .style("margin", "auto 0")
            .attr("id", toggleId)
            .style("display", "flex")
            .style("flex-direction", "row")
            .style("justify-content", "space-evenly")
            .style("position", "relative");

        toggle
            .append("label")

        toggle
            .append("input")
            .attr("type", "checkbox")
            .attr("checked", true)
            .on("click", () => {
                toggled = !toggled;
                dataSetter(toggled);
            })

        toggle
            .append("span")
            .classed("slider round", true)
    }

    my.toggleId = function (_) {
        return arguments.length ? ((toggleId = _), my) : toggleId;
    }

    my.dataSetter = function (_) {
        return arguments.length ? ((dataSetter = _), my) : dataSetter;
    }

    my.toggleName = function (_) {
        return arguments.length ? ((toggleName = _), my) : toggleName;
    }

    return my;
}