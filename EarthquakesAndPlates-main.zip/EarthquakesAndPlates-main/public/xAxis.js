const {select} = d3

export const generateXAxis = () => {
  const margin = { top: 40, right: 20, bottom: 20, left: 37 };
  const width = 0.14 * window.innerWidth;

  const xAxisContainer = select("div#x-axis");

  // Create scales for x and y axes
  const xScale = d3.scaleLinear()
      .domain([0, 1000])
      .range([0, width]);

  // Create axes
  const xAxis = d3.axisTop(xScale)
      .ticks(4)
      .tickFormat(d3.format("d"));

  // Append x-axis
  const xsvg = xAxisContainer.append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", margin.top)

  const xchart = xsvg.append("g")
      .attr("transform", `translate(${margin.left}, ${35})`);
  xchart.append("g")
      .attr("class", "x-axis")
      .call(xAxis);

  // Append x-axis label
  xchart.append("text")
    .attr("class", "x-label")
    .attr("x", width / 2)
    .attr("y", -20)
    .style("text-anchor", "middle")
    .text("Distance (km)");

  // Append A
  xchart.append("text")
    .attr("class", "A-label")
    .attr("x", 0)
    .attr("y", -20)
    .style("text-anchor", "middle")
    .text("A");

  // Append A
  xchart.append("text")
    .attr("class", "A-label")
    .attr("x", 200)
    .attr("y", -20)
    .style("text-anchor", "middle")
    .text("B");
}

