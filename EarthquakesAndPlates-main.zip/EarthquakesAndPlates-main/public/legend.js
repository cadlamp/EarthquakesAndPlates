const { geoEqualEarth, geoPath, scaleLog, extent, descending, select, zoom, interpolate, zoomIdentity} = d3

let data;
let magnitudeFilter = [1, 10]
let depthFilter = [0, 700]
let colorScale;
let rScale;
let distanceBars = 225;
let rightOffset = 25;


export const legend = () => {  

  const generateLegend = (earthquakeSVG) => {
    createColorScale();
    
    createRScale();

    // Setting up the legend for the magnitude encodings
    const legend = earthquakeSVG
      .selectAll("g.legend")
      .data([null])
      .join("g")
      .attr("id", "legend")
      .append("svg")
      .attr("x", "89%")
      .attr("y", "6%")
      .attr("width", 100)
      .attr("height", 415)
      .style("padding", "3")

    // legend
    //   .selectAll("rect")
    //   .data([null])
    //   .join("rect")
    //   .attr("width", 80)
    //   .attr("height", 415)
    //   .attr("stroke", "grey")
    //   .attr("stroke-width", '0.1rem')
    //   .attr("fill", "grey")
    //   .attr("ry", "0.5rem")

    legend
      .selectAll("subtitle1")
      .data([null])
      .join("text")
      .attr("transform", `translate(${0}, ${13})`)
      .attr("fill", "black")
      .text("Magnitude")
      .style("font", "bold 15px black")
      .style("font-family", "Roboto Slab")

    // Receives [min,max] and returns all values in-between min and max in array form
    const magnitudeLegendData = (data) => {
      const legendData = [];
      const step = (data[1] - data[0]) / 7.0;
      for (let i = data[0]; i < data[1]; i = i + step) {
        legendData.push(i);
      }
      return legendData;
    }
    
    // The border around the circles
    legend.append("rect")
      .attr("width", 25)
      .attr("height", 175)
      .attr("stroke", "grey")
      .attr("fill", "grey")
      .attr("transform", `translate(${rightOffset}, 20)`)
      .attr("ry", "1%");

    // The magnitude circles
    legend.selectAll("magnitudeCircles")
      .data(magnitudeLegendData(extent(data, (d) => d.magnitude)))
      .join("circle")
      .attr("r", d => rScale(d))
      .attr("transform", (d, i) => `translate(${rightOffset + 12.5}, ${(i * 5.5 * d/2) + 30})`)
      .attr("fill", "white")
      .attr("opacity", 0.5)
      .attr("stroke", "black")
      .attr("stroke-width", 1)    

    // The magnitude numbers
    legend.selectAll("magnitudeLegendNums")
      .data(extent(data, (d) => d.magnitude))
      .join("text")
      .attr("class", "legend-nums")
      .attr("transform", (d, i) => `translate(${rightOffset - 21}, ${i * 142 + 38})`)
      .text((d) => `${d}`)
      .style("font", "13px black")

    legend
      .selectAll("subtitle2")
      .data([null])
      .join("text")
      .attr("transform", `translate(${rightOffset - 7.5}, ${distanceBars + 8})`)
      .attr("fill", "black")
      .text("Depth")
      .style("font", "bold 15px black")
      .style("font-family", "Roboto Slab")
    
    // Create linear gradient for the color scale
    const defs = legend.append("defs");
    const linearGradient = defs.append("linearGradient")
        .attr("id", "color-gradient")
        .attr("x1", "0%")
        .attr("y1", "0%")
        .attr("x2", "0%")
        .attr("y2", "100%");

    // Add color stops to the gradient
    linearGradient.append("stop")
        .attr("offset", "0%")
        .attr("stop-color", "blue");
    linearGradient.append("stop")
        .attr("offset", "50%")
        .attr("stop-color", "yellow");
    linearGradient.append("stop")
        .attr("offset", "100%")
        .attr("stop-color", "red");

    // Append the bar representing the color scale
    legend.append("rect")
        .attr("width", 25)
        .attr("height", 175)
        .attr("fill", "url(#color-gradient)")
        .attr("transform", `translate(${rightOffset}, ${distanceBars + 15})`)
        .attr("ry", "1%");
        // .attr("stroke", "black");


    legend.selectAll("depthLegendNums")
        .data([0, 250, 680]) // Include 250 in the data array
        .join("text")
        .attr("class", "legend-nums")
        .attr("transform", (d, i) => `translate(${rightOffset - 6}, ${i * 72.5 + distanceBars + 35})`) // Adjust positioning based on the number of data points
        .attr("text-anchor", "end") // Set text alignment to "end" for right-aligning
        .text((d) => `${d}`)
        .style("font", "13px black");
  }

  //*************************************//
  //          HELPER FUNCTIONS           //
  //*************************************//

  // The scale for the colors
  function createColorScale() {
    // Sets up a color scale for the points based on depth
    colorScale = (depth) => {
    if (depth <= 70) {
      // Scale depths from 0 to 70 km using blue to yellow color interpolation
      // These are considered shallow earthquakes
      return interpolate("blue", "yellow")(depth / 70);
    } else  if (depth <= 250){
      // Scale depths from 70 to 300 km using blue to red color interpolation
      // These are considered intermediate earthquakes
      return interpolate("yellow", "red")(depth / 250);
    } else {
      // Depths beyond 250 km are mapped to the color red
      // These are considered deep earthquakes
      return "red";
    }};
  }

  // The radius scale
  function createRScale() {
    // Sets up radius scaling for points based on magnitude
    rScale = scaleLog(extent(data, (d) => d.magnitude), [1,10]);
  }

  //*************************************//
  //          ANONYMOUS FUNCTIONS        //
  //*************************************//

  generateLegend.data = function (_) {
    return arguments.length ? ((data = _), generateLegend) : data;
  }
  
  return generateLegend;
}
