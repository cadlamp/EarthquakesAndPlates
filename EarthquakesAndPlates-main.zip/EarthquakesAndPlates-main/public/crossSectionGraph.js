const { geoEqualEarth, geoPath, scaleLog, extent, descending, select, zoom, interpolate, zoomIdentity} = d3

let data;
let graphFilter;
let currRegion;
let currHighlight = new Set()
let plateData;
let magnitudeFilter = [1, 10]
let depthFilter = [0, 700]
let colorScale;
let distanceArr = [];
let depthArr = [];
let chartData = [];
let subductionBorders = [];


export const graphVisualization = (groupName) => {  

  const generateGraph = (graphSVG) => {
    getSubduction();
    calculateDistance();
    cleanData();

    const margin = { top: 40, right: 20, bottom: 18, left: 37 };
    const width = 0.14 * window.innerWidth;
    const height = width * 0.38;

    // Create scales for x and y axes
    const xScale = d3.scaleLinear()
      .domain([0, 1000])
      .range([0, width]);
    const yScale = d3.scaleLinear()
      .domain([0, d3.max(chartData, d => d[1])])
      .range([0, height]);
  
    // Create axes
    const yAxis = d3.axisLeft(yScale)
      .tickValues([yScale.domain()[0], yScale.domain()[1], (yScale.domain()[0] + yScale.domain()[1]) / 2])
      .tickFormat(d3.format("d"))
      .tickPadding(8);

    const graphData = [
      { region: "Tonga", text: "Tonga" },
      { region: "Solomon", text: "Solomon" },
      { region: "Andes", text: "Andes" },
      { region: "Japan", text: "Japan" },
      { region: "Central America", text: "Central America" }
    ];

    graphData.forEach((data, index) => {
      let isClicked = [false, false, false, false, false];
      let moused;
      const svg = graphSVG.append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.bottom)
        .attr("id", `chart-${index}`);
        
    
      const chart = svg.append("g")
        .attr("transform", `translate(${margin.left}, ${5})`);
    
      chart.append("rect")
        .attr("width", width)
        .attr("height", height)
        .attr("fill", "lightgrey")
        .attr("stroke", "black")
        .attr("stroke-width", '0.1rem');
    
      // Append y-axis
      chart.append("g")
        .attr("class", "y-axis")
        .call(yAxis)
        .selectAll("text")
        .attr("dx", "2em")
        .attr("dy", "-0.8em")
        .attr("transform", "rotate(-90)");
      
      
      // Append y-axis label to middle chart
      if (index == 2) {      
        chart.append("text")
          .attr("class", "y-label")
          .attr("transform", "rotate(-90)")
          .attr("x", -height / 2)
          .attr("y", -margin.left + 15)
          .style("text-anchor", "middle")
          .text("Depth (km)");
      } 
    
      // Create circles for scatter plot
      chart.selectAll(".scatter-circle")
        .data(chartData.filter(d => d[3] === data.region))
        .enter()
        .append("circle")
        .attr("class", "scatter-circle")
        .attr("cx", d => xScale(d[0]))
        .attr("cy", d => yScale(d[1]))
        .attr("r", 4)
        .attr("fill", d => d[2])
        .attr("opacity", 0.7);
    
      chart.append("text")
        .attr("class", "chart-title")
        .attr("x", width - 75)
        .attr("y", 17)
        .style("font-size", "15px")
        .text(data.text);

      svg.on('mouseover', function() {
        d3.select(this).select('rect').attr("stroke-width", '0.2rem');
        if (moused != index) {
          currHighlight.add(data.region);
          currRegion = (data.region);          
          graphFilter(currHighlight);
          moused = index;
        }
      })
      .on('mouseleave', function() {
        d3.select(this).select('rect').attr("stroke-width", '0.1rem');
        moused = -1;
        // Check if the relatedTarget is null or not a descendant of the SVG
        if (!isClicked[index]) { // && (!event.relatedTarget || !svg.node().contains(event.relatedTarget))
          console.log("Region: ", currRegion);
          currHighlight.delete(currRegion);            
          graphFilter(currHighlight);
        }
      })
      .on('click', () => {
        if (isClicked[index]) {
          // If already clicked, change the color back to grey
          chart.select('rect').attr("fill", "lightgrey");
          isClicked[index] = false; // Update the state variable
        } else {
          // If not clicked, change the color to lightblue
          chart.select('rect').attr("fill", "#96b8b0");
          isClicked[index] = true; // Update the state variable
        }
      });
    });  
  }

  //*************************************//
  //          HELPER FUNCTIONS           //
  //*************************************//

  // Calculate the nearest subduction zone boundary
  function calculateDistance() {
    // Set up variables
    var earthRadius = 6371;
    var latDiff, longDiff, pLat, pLong, color, group;
    var a, b, c;
    var minDistance;
    // Iterate through each data point
    // TODO(echess) create a subset of data containing quakes specifically related to subduction zones
    data.forEach(element => {
      minDistance = 10000;
      // Set the lat and long of current point
      pLat = element.latitude;
      pLong = element.longitude;
      if (-40 < pLat && pLat < -14 && (178 < pLong || pLong < -172)) {
        group = "Tonga";
        color = "#ff595e";
      } else if (-24 < pLat && pLat < -3 && 145 < pLong && pLong < 174) {
        group = "Solomon";
        color = "#1982c4";
      } else if (-39 < pLat && pLat < 5 && -80 < pLong && pLong < -60) {
        group = "Andes";
        color = "#8ac926";
      } else if ((10 < pLat && pLat < 35 && 137 < pLong && pLong < 147)
                || (35.5 < pLat && pLat < 63 && 129 < pLong && pLong < 171.1)) {
        group = "Japan";
        color = "#6a4c93";
      } else if ((7 < pLat && pLat < 14 && -90 < pLong && pLong < -82)
                || (13 < pLat && pLat < 20 && -110 < pLong && pLong < -90)) {
        group = "Central America"
        color = "#2a9d8f";
      } else {
        group = "";
      }
      if (group != "") {
        // console.log("Lat: ", pLat, "Long: ", pLong)
        // Iterate through each border
        subductionBorders.forEach(border => {
          // Iterate throuhg each long/lat on the border
          border.geometry.coordinates.forEach(longLat => {
            // if (longLat[0] > 125 && longLat[0] < 135 && longLat[1] > 25 ) {
            //   console.log(border)
            // }
            latDiff = pLat - longLat[1];
            longDiff = pLong - longLat[0];
            a = Math.sin(deg2rad(latDiff)/2) * Math.sin(deg2rad(latDiff)/2) +
            Math.cos(deg2rad(longLat[1])) * Math.cos(deg2rad(pLat)) * 
            Math.sin(deg2rad(longDiff)/2) * Math.sin(deg2rad(longDiff)/2);
            b = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            c = earthRadius * b;
            // console.log(earthRadius, b);
            minDistance = Math.min(minDistance, c);
          });
        });
        // Add to chart Data
        // console.log(minDistance, element.depth);
        chartData.push([minDistance, element.depth, color, group]);
        // distanceArr.push(minDistance);
      }
    });
  }

  // Helper for calcDistance function
  function deg2rad(deg) {
    return deg * (Math.PI/180)
  }

  function populateChartData() {
    // populate array of depths
    data.forEach(element => {
      depthArr.push(element.depth);
    });
    // Populate chart data
    d3.range(depthArr.length).forEach(i => {
      chartData.push([distanceArr[i], depthArr[i], colorScale(depthArr[i])]);
    })
    // console.log(chartData);
  }

  // Get subduction zones
  function getSubduction() {
    let tempSubBorders = plateData.features;
    let plateA, plateB;
    tempSubBorders.filter(feature => feature.properties.Type === 'subduction').forEach(border => {
      plateA = border.properties.PlateA;
      plateB = border.properties.PlateB;
      if (plateA == "EU" || plateB == "EU" || plateB == "PS") {
      } else {
        subductionBorders.push(border);        
      }
  });

  }

  function cleanData(){
    // Filtering by depth and magnitude
    let i = 0;
    chartData.forEach(p => {
      if (p[3] == "Solomon") {
        if (p[1] < (2.5 * p[0] - 1000) || p[0] > 240 && p[1] > (1 / (p[0] - 240) + 100)) {
          chartData[i][3] = null;
        }
      } else if (p[3] == "Japan") {
        if (p[1] < (0.5 * p[0] - 350) || p[1] > (p[0] + 300)) {
          chartData[i][3] = null;
        }
      } else if (p[3] == "Andes") {
        if (p[1] < (0.5 * p[0] -250)) {
          chartData[i][3] = null;
        }
      }
      i++;
    })
  }

  //*************************************//
  //          ANONYMOUS FUNCTIONS        //
  //*************************************//


  //Draw the graph
  //TODO this honestly needs to me moved to its own class
  generateGraph.update = function() {
    // filterData();
    
    
    return generateGraph;
  }

  generateGraph.data = function (_) {
    return arguments.length ? ((data = _), generateGraph) : data;
  }

  generateGraph.plateData = function (_) {
    return arguments.length ? ((plateData = topojson.feature(_, _.objects.PB2002_boundaries)), generateGraph) : plateData;
  }

  generateGraph.graphFilter = function (_) {
    return arguments.length ? ((graphFilter = _), generateGraph) : graphFilter;
}
  
  // generateGraph.magnitudeFilter = function (_) {
  //   return arguments.length ? ((magnitudeFilter = _), generateGraph) : magnitudeFilter;
  // }
  
  // generateGraph.depthFilter = function (_) {
  //   return arguments.length ? ((depthFilter = _), generateGraph) : depthFilter;
  // }
  
  // generateGraph.platesVisible = function (_) {
  //   return arguments.length ? ((platesVisible = _), generateGraph) : platesVisible;
  // }
  
  return generateGraph;
}
